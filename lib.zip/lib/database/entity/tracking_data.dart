// import 'package:floor/floor.dart';
// @Entity(tableName: "tbl_tracking_data")
// class TrackingData {
//   @PrimaryKey(autoGenerate: true)
//   int id;
//   int employeeId;
//   String dateTime;
//   String locationString;
//   String createdAt;
//   String updatedAt;
//
// }
