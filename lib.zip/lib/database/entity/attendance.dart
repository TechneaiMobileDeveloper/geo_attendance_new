// import 'package:floor/floor.dart';
//
// @Entity(tableName: "tbl_attendance")
// class Attendance {
//   @PrimaryKey(autoGenerate: true)
//   int id;
//   String employeeId;
//   String date;
//   String inTime;
//   String outTime;
//   String inLocation;
//   String outLocation;
//
//   Attendance(this.id, this.employeeId,this.inTime,this.outTime,this.inLocation,this.outLocation);
//
// }
