// import 'dart:async';
//
// import 'package:floor/floor.dart';
// import 'package:geo_attendance_system/database/dao/attendance.dart';
// import 'package:geo_attendance_system/database/entity/tracking_data.dart';
//
//
// import 'entity/attendance.dart';
// part 'AppDatabase.g.dart';
// @Database(version: 1, entities: [Attendance])
// abstract class AppDatabase extends FloorDatabase {
//   AttendanceDao get personDao;
//
//
// }
