import 'package:flutter/material.dart';
import 'package:geo_attendance_system/utils/sizes.dart';
import 'package:geo_attendance_system/utils/text_styles.dart';

import 'app_colors.dart';

ThemeData appTheme = ThemeData(
  iconTheme: IconThemeData(size: Sizes.s20, color: Colors.black),
  brightness: Brightness.light,
  elevatedButtonTheme: ElevatedButtonThemeData(
      style: ButtonStyle(
          backgroundColor: MaterialStateProperty.all(Colors.black87),
          textStyle:
              MaterialStateProperty.all(TextStyle(color: Colors.black)))),
  primaryColor: AppColors.greyText,
  primaryColorBrightness: Brightness.light,
  primaryColorLight: AppColors.greyTextMedium,
  primaryColorDark: AppColors.primary,
  accentColor: AppColors.primaryLightColor,
  accentColorBrightness: Brightness.light,
  scaffoldBackgroundColor: Colors.white,
  bottomAppBarColor: AppColors.primaryLightColor,
  cardColor: Colors.white,
  colorScheme: ColorScheme(
      brightness: Brightness.light,
      primary: AppColors.fontGray,
      onPrimary: AppColors.white,
      secondary: AppColors.greyText,
      onSecondary: AppColors.greyLight,
      onError: AppColors.red,
      error: AppColors.red,
      background: AppColors.white,
      onBackground: AppColors.white,
      surface: AppColors.white,
      onSurface: AppColors.black),
  dividerColor: Colors.black,
  splashFactory: InkSplash.splashFactory,
  materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
  fontFamily: FontFamily.regular,
);
