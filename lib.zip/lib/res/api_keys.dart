class APIKeys {
  static var deviceId = "device_id";

  static String get msg => 'msg';

  static String get username => 'email';

  static String get password => 'password';

  static String get employeeId => 'employee_id';

  static String get periodId => 'period_id';
}
