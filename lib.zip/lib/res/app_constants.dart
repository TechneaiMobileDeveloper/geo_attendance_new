class Constants {
  static const int status = 1;
  static const int AttendanceTypeIn = 0;
  static const int AttendanceTypeOut = 1;
}
