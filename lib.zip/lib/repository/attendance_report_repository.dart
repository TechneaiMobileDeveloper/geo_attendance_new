import 'package:geo_attendance_system/network/urls.dart';
import 'package:get/get.dart';
import '../controllers/setting_controller.dart';
import '../utils/methods.dart';

class AttendanceReportRepository {

 // final apiClient =

}
