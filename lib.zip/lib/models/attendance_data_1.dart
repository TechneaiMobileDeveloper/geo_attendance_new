import 'package:get/get.dart';

class AttendanceData {
  final data = <Data>[].obs;
  String message;
  bool success;

  AttendanceData({this.message, this.success});

  AttendanceData.fromJson(dynamic json) {
    if (json['data'] != null) {
      data.value = <Data>[];
      json['data'].forEach((v) {
        data.add(new Data.fromJson(v));
      });
    }
    message = json['path'];
    success = json['success'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.data != null) {
      data['data'] = this.data.map((v) => v.toJson()).toList();
    }
    data['path'] = this.message;
    data['success'] = this.success;
    return data;
  }
}

class Data {
  int id;
  int empId;
  String cDate;
  String inTime;
  String outTime;
  String inLocation;
  String outLocation;
  String inImagePath;
  String outImagePath;
  int acceptance;
  String userName;
  int isManualApprove;

  Data(
      {this.id,
      this.empId,
      this.cDate,
      this.inTime,
      this.outTime,
      this.inLocation,
      this.outLocation,
      this.inImagePath,
      this.outImagePath,
      this.acceptance,
      this.userName,
      this.isManualApprove});

  Data.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    empId = json['emp_id'];
    cDate = json['c_date'];
    inTime = json['inTime'];
    outTime = json['OutTime'];
    inLocation = json['inLocation'];
    outLocation = json['outLocation'];
    inImagePath = json['in_image_path'];
    outImagePath = json['out_image_path'];
    acceptance = json['acceptance'];
    userName = json['userName'];
    isManualApprove = json['is_manual_approve'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['emp_id'] = this.empId;
    data['c_date'] = this.cDate;
    data['inTime'] = this.inTime;
    data['OutTime'] = this.outTime;
    data['inLocation'] = this.inLocation;
    data['outLocation'] = this.outLocation;
    data['in_image_path'] = this.inImagePath;
    data['out_image_path'] = this.outImagePath;
    data['acceptance'] = this.acceptance;
    data['userName'] = this.userName;
    return data;
  }
}

// class AttendanceData {
//   int id;
//   int empId;
//   String cDate;
//   String inTime;
//   Null outTime;
//   String inLocation;
//   String outLocation;
//   String inImagePath;
//   String outImagePath;
//   int acceptance;
//
//   AttendanceData(
//       {this.id,
//         this.empId,
//         this.cDate,
//         this.inTime,
//         this.outTime,
//         this.inLocation,
//         this.outLocation,
//         this.inImagePath,
//         this.outImagePath,
//         this.acceptance});
//
//   AttendanceData.fromJson(Map<String, dynamic> json) {
//     id = json['id'];
//     empId = json['emp_id'];
//     cDate = json['c_date'];
//     inTime = json['inTime'];
//     outTime = json['OutTime'];
//     inLocation = json['inLocation'];
//     outLocation = json['outLocation'];
//     inImagePath = json['in_image_path'];
//     outImagePath = json['out_image_path'];
//     acceptance = json['acceptance'];
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['id'] = this.id;
//     data['emp_id'] = this.empId;
//     data['c_date'] = this.cDate;
//     data['inTime'] = this.inTime;
//     data['OutTime'] = this.outTime;
//     data['inLocation'] = this.inLocation;
//     data['outLocation'] = this.outLocation;
//     data['in_image_path'] = this.inImagePath;
//     data['out_image_path'] = this.outImagePath;
//     data['acceptance'] = this.acceptance;
//     return data;
//   }
// }
