import 'dart:async';
import 'dart:io';
import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:geo_attendance_system/controllers/dashboard_controller.dart';
import 'package:geo_attendance_system/db/database.dart';
import 'package:geo_attendance_system/res/res_controller.dart';
import 'package:geo_attendance_system/service/facenet.service.dart';
import 'package:geo_attendance_system/utils/utils_controller.dart';
import 'package:get/get.dart';

// import 'package:google_ml_kit/google_ml_kit.dart';
import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';
import 'package:path_provider/path_provider.dart';
import '../widgets/custom_text_widget.dart';
import 'camera_view.dart';
import 'painters/face_detector_painter.dart';

class FaceDetectorView extends StatefulWidget {
  final String username, password;
  final bool isSignUp;
  final bool isAuto;

  final String empId;
  final bool isEdit;
  final bool conflict;

  final FaceDetector faceDetector;
  final FaceNetService faceNetService;
  final CameraController cameraController;

  FaceDetectorView(this.username, this.password, this.isSignUp,
      this.faceDetector, this.faceNetService,
      {this.empId,
      this.isEdit = false,
      this.isAuto = false,
      this.conflict = false,
      this.cameraController});

  @override
  _FaceDetectorViewState createState() =>
      _FaceDetectorViewState(this.faceDetector, this.faceNetService);
}

class _FaceDetectorViewState extends State<FaceDetectorView> {
  bool save = false;
  bool isBusy = false;
  var modalLoaded = false;
  bool loaded = false;
  bool isDispose = false;
  CustomPaint customPaint;
  Map<String, dynamic> result;
  XFile file;
  String _key = "";
  List<Face> faces = [];
  InputImage mInputimage;
  Timer _timer;
  String dist;
  DataBaseService _dataBaseService = DataBaseService();
  FaceNetService faceNetService;
  int count = 0;
  bool isEnableButton = false;
  FaceDetector faceDetector;
  CameraController cameraController;
  bool isTakingPicture = false;
  File captureImage;

  final dashboardController = Get.find<DashboardController>();

  _FaceDetectorViewState(this.faceDetector, this.faceNetService);

  @override
  void dispose() {
    faceDetector.close();
    save = false;
    isDispose = true;
    _timer.cancel();
    super.dispose();
  }

  @override
  void initState() {
    loadTensorModal();
    super.initState();
  }

  void startTimer() {
    const oneSec = const Duration(seconds: 1);
    _timer = new Timer.periodic(oneSec, (Timer timer) {
      count++;
      if (count > 10) {
        if (timer.isActive) {
          timer.cancel();
        }
        if (!widget.isSignUp) {
          showConfirmDialog(() {
            isBusy = false;
            save = false;
            startTimer();
            if (Get.isDialogOpen) {
              Future.delayed(Duration.zero, () {
                Get.back();
              });
            }
          }, () {
            isBusy = false;
            save = false;
            try {
              _timer.cancel();
              Future.delayed(
                  Duration.zero,
                  () => Get.dialog(showBottomDialog(_key),
                      barrierDismissible: false));
            } catch (ex) {
              print(ex.toString());
            }
          }, Strings.userNotFound, Strings.tryAgain, Strings.retry,
              Strings.cancle);
          count = 0;
        }
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return faceDetector != null && modalLoaded
        ? WillPopScope(
            onWillPop: () {
              Get.back();
              return;
            },
            child: Stack(alignment: Alignment.center, children: [
              CameraView(
                  title: 'Face Detector',
                  customPaint: customPaint,
                  controller: widget.cameraController,
                  onImage: (inputImage, controller, _cameraController) {
                    this.mInputimage = inputImage;
                    this.cameraController = _cameraController;
                    if (!save) {
                      Future.delayed(Duration.zero, () {
                        processImage(
                            this.mInputimage, controller, _cameraController);
                      });
                    }
                  },
                  initialDirection: CameraLensDirection.front),
              Visibility(
                visible: false,
                child: Positioned(
                    bottom: Sizes.s50,
                    child: Text("Dist=$dist",
                        style: TextStyles.textStyle
                            .copyWith(fontSize: FontSizes.s20))),
              ),
              Visibility(
                visible: !widget.isAuto,
                child: Align(
                    alignment: Alignment.bottomCenter,
                    child: Container(
                      margin: EdgeInsets.only(bottom: Sizes.s50),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Visibility(
                            child: SizedBox(
                              width: Sizes.s100,
                              child: AppPrimaryButton(
                                text: "Add User",
                                onPressed: this.isEnableButton
                                    ? () {
                                        signUP(this.mInputimage);
                                      }
                                    : null,
                              ),
                            ),
                          ),
                          SizedBox(
                            width: Sizes.s10,
                          ),
                          Visibility(
                            visible: false,
                            child: Expanded(
                              flex: 1,
                              child: AppPrimaryButton(
                                text: "Capture Image",
                                onPressed: () {
                                  // signIn();
                                },
                              ),
                            ),
                          )
                        ],
                      ),
                    )),
              )
            ]),
          )
        : Center(
            child: CircularProgressIndicator(
              color: AppColors.primary,
            ),
          );
  }

  Future<void> processImage(InputImage inputImage, CameraImage image,
      CameraController cameraController) async {
    try {
      if (inputImage != null) {
        if (isBusy) return;
        if (faceDetector != null) {
          isBusy = true;
          final faces = await faceDetector.processImage(inputImage);
          this.faces = faces;
          print('Found ${faces.length} faces');

          if (inputImage.inputImageData.size != null &&
              inputImage.inputImageData.imageRotation != null &&
              faces.length > 0) {
            final painter = FaceDetectorPainter(
                faces,
                inputImage.inputImageData.size,
                inputImage.inputImageData.imageRotation,
                widget.isSignUp);
            customPaint = CustomPaint(painter: painter);
          } else {
            customPaint = null;
          }

          if (!isDispose) {
            setState(() {});
          }
          await Future.delayed(Duration(milliseconds: 10));
          if (image != null) {
            if (this.faces != null) {
              if (this.faces.length > 0) {
                Face face = this.faces.first;
                if (face.headEulerAngleY < 10 &&
                    face.headEulerAngleY > -10 &&
                    face.rightEyeOpenProbability > 0.1 &&
                    face.leftEyeOpenProbability > 0.1) {
                  if (!isDispose) {
                    setState(() {
                      isEnableButton = true;
                    });
                  }

                  if (!save && modalLoaded) {
                    await faceNetService.setCurrentPrediction(image, face);
                    if (!widget.isSignUp) {
                      if (widget.empId == null)
                        result = await signIn(inputImage);
                      else if (_key != null) {
                        if (_key.isNotEmpty)
                          result = await signIn(inputImage, key: _key);
                      }
                      if (!isDispose) {
                        if (result != null) {
                          if (result['predRes'] != null) {
                            _timer.cancel();
                            showConfirmDialog(faceDetectedCallback, () {
                              try {
                                Future.delayed(
                                    Duration.zero,
                                    () => Get.dialog(showBottomDialog(_key),
                                        barrierDismissible: false));
                              } catch (ex) {
                                print(ex.toString());
                              }
                            },
                                Strings.faceDetected,
                                "Hello ${result['predRes'].toString().split(":")[0]}",
                                Strings.IN,
                                Strings.OUT,
                                result: result);
                          } else {
                            isBusy = false;
                            save = false;
                          }
                        } else {
                          isBusy = false;
                          save = false;
                        }
                      }
                    } else {
                      if (widget.isAuto) signUP(inputImage);
                      isBusy = false;
                    }
                  } else {
                    isBusy = false;
                  }
                } else {
                  if (!isDispose) {
                    setState(() {
                      isEnableButton = false;
                    });
                  }
                  isBusy = false;
                }
              } else {
                isBusy = false;
              }
            } else {
              isBusy = false;
            }
          } else {
            isBusy = false;
          }
        } else {
          isBusy = false;
          loadFaceML();
        }
      } else {
        isBusy = true;
      }
    } on PlatformException catch (ex) {
      Common.toast(Strings.opps);
      loadFaceML();
      isBusy = false;
      logErrorInFile(ex.toString());
      print("platformError=${ex.toString()}");
    }
  }

  void faceDetectedCallback(dynamic result) async {
    try {

      Get.back();

      if (cameraController != null) {

        await Future.delayed(Duration(milliseconds: 100));

        if (cameraController.value.isStreamingImages) {
          await cameraController.stopImageStream();
        }

        await Future.delayed(Duration(milliseconds: 200));

        if (!cameraController.value.isTakingPicture) {
              file = await cameraController.takePicture();
              final bytes = await file.readAsBytes();
              final tempDir = await getTemporaryDirectory();
              captureImage = await File('${tempDir.path}/image.jpeg').create();
              await captureImage.writeAsBytes(bytes);
        }

        faceNetService.setPredictedData(null);
        isDispose = true;
        _timer.cancel();

        Navigator.pop(context, {
          "isSignUp": widget.isSignUp,
          "result": result == null ? null : result['predRes'],
          "empId": widget.empId,
          "username": dashboardController.usernameController.text,
          "image": captureImage,
          "type": result == null ? null : result['type'],
          "error": false
        });
      } else {
        Common.toast(Strings.camera_error);
      }
    } catch (ex) {
      print(ex.toString());
    }
  }

  // void faceDetectedCallback(dynamic result) async {
  //   try {
  //     if (cameraController != null) {
  //       await Future.delayed(Duration(seconds: 1));
  //       if (cameraController.value.isStreamingImages) {
  //         await cameraController.stopImageStream();
  //       }
  //
  //       await Future.delayed(Duration(seconds:1));
  //
  //       if (!cameraController.value.isTakingPicture) {
  //         file = await cameraController.takePicture();
  //
  //         final bytes = await file.readAsBytes();
  //         final tempDir = await getTemporaryDirectory();
  //
  //         captureImage = await File('${tempDir.path}/image.jpeg').create();
  //
  //         await captureImage.writeAsBytes(bytes);
  //       }
  //
  //       faceNetService.setPredictedData(null);
  //       isDispose = true;
  //       _timer.cancel();
  //
  //       Navigator.pop(context, {
  //         "isSignUp": widget.isSignUp,
  //         "result": result == null ? null : result['predRes'],
  //         "empId": widget.empId,
  //         "username": dashboardController.usernameController.text,
  //         "image": captureImage,
  //         "error": false
  //       });
  //     } else {
  //       Common.toast(Strings.camera_error);
  //     }
  //   } catch (ex) {
  //     print(ex.toString());
  //   }
  // }

  void signUP(InputImage image) async {
    try {
      bool error = false;
      Map<String, dynamic> result;
      final bytes = image.bytes;
      String predRes;
      final tempDir = await getTemporaryDirectory();

      if (!isDispose) {
        setState(() {
          save = true;
        });
      }
      File captureImage = await File('${tempDir.path}/image.png').create();
      captureImage.writeAsBytes(bytes);

      await _dataBaseService.loadDB();

      if (!widget.isEdit) {
        result = faceNetService.predict();
        if (result != null) predRes = result["predRes"];
      } else {
        result = faceNetService.predict(key: widget.empId, isEdit: true);
        if (result != null) predRes = result["predRes"];
      }

      if (predRes == null || widget.conflict) {
        error = false;
        _dataBaseService.saveData(
            widget.username, widget.password, faceNetService.predictedData,
            isConflict: widget.conflict);
      } else {
        error = true;
        Common.toast(Strings.userAlreadyExits);
      }

      Navigator.pop(context, {
        "isSignUp": widget.isSignUp,
        "result": result,
        "image": captureImage,
        "error": error
      });
      isBusy = false;
    } catch (ex) {
      print(ex.toString());
    }
  }

  Future<Map<String, dynamic>> signIn(InputImage image, {String key}) async {
    Map<String, dynamic> result;
    result = key == null
        ? faceNetService.predict()
        : faceNetService.predict(key: key);
    log("result=$result");

    if (!isDispose) {
      isBusy = false;
      save = false;
    }
    return result;
  }

  // void paintContour(FaceContourType type) {
  //   final faceContour = faces[0].getContour(type);
  //   if (faceContour.positionsList != null) {
  //     for (Offset point in faceContour.positionsList) {
  //       log("type=${type.toString()},${point.toString()}");
  //     }
  //   }
  // }

  void loadFaceML() {
    try {
      faceDetector = FaceDetector(
          options: FaceDetectorOptions(
        enableContours: true,
        enableClassification: true,
      ));
    } catch (ex) {
      print(ex.toString());
    }
  }

  void loadTensorModal() async {
    try {
      _key = faceNetService.findKey(widget.empId);
      setState(() {
        modalLoaded = true;
      });
      startTimer();
    } catch (ex) {
      loadTensorModal();
    }
  }

  void changeState() {
    if (mounted) {
      setState(() {
        save = true;
      });
    }
  }

  void showConfirmDialog(Function onConfirm, VoidCallback onCancle,
      String title, String middleText, String textConfirm, String textCancle,
      {dynamic result, dynamic cameraImage, int empId}) async {
    try {
      save = true;
      isBusy = true;
      Get.defaultDialog(
          barrierDismissible: false,
          title: title,
          content: WillPopScope(
            onWillPop: () {
              Get.back();
              Get.back();
              return;
            },
            child: Container(
              margin: EdgeInsets.symmetric(horizontal: FontSizes.s12),
              child: Column(
                children: [
                  CustomText(
                    text: middleText,
                    fontSize: FontSizes.s18,
                  ),
                  C20(),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton(
                            onPressed: () async {
                              var out = await dashboardController.dbHelper
                                  .getIsPunched(int.parse(widget.empId));
                              if (out['type'] == "OUT" ||
                                  out['type'] == 'FIRST') {
                                clickEvent(textConfirm, onConfirm, cameraImage,
                                    result);
                              } else {
                                Common.toast(Strings.alreadyPunchedIn);
                              }
                            },
                            child: CustomText(
                              text: textConfirm,
                              fontSize: FontSizes.s12,
                              color: Colors.white,
                            )),
                      ),
                      C20(),
                      Expanded(
                        child: ElevatedButton(
                            onPressed: () async {
                              var out = await dashboardController.dbHelper
                                  .getIsPunched(int.parse(widget.empId),
                                      Inout: 1);
                              if (out['type'] == "IN" ||
                                  textCancle == Strings.cancle) {
                                outClickEvent(textCancle, onConfirm, onCancle,
                                    result, cameraImage);
                              } else {
                                if (out['type'] == 'FIRST') {
                                  Common.toast(Strings.not_applicable);
                                } else
                                  Common.toast(Strings.alreadyPunchedOut);
                              }
                            },
                            child: CustomText(
                              text: textCancle,
                              fontSize: FontSizes.s12,
                              color: Colors.white,
                            )),
                      ),
                    ],
                  )
                ],
              ),
            ),
          ));
    } on Exception catch (ex) {
      Common.toast(ex.toString());
    }
  }

  void clickEvent(String textConfirm, Function onConfirm,
      CameraImage cameraImage, dynamic result) {
    dashboardController.inClicked.value = true;
    if (textConfirm == "IN") {
      if (result != null && cameraImage != null) {
        result['type'] = 0;
        onConfirm(result, cameraImage);
      } else if (result != null) {
        result['type'] = 0;
        onConfirm(result);
      } else
        onConfirm();
    } else {
      onConfirm();
    }
    //Get.back();
  }

  outClickEvent(String textCancle, Function onConfirm, VoidCallback onCancle,
      dynamic result, CameraImage cameraImage) {
    dashboardController.outClicked.value = true;
    if (textCancle == "OUT") {
      if (result != null && cameraImage != null) {
        result['type'] = 1;
        onConfirm(result, cameraImage);
      } else if (result != null) {
        result['type'] = 1;
        onConfirm(result);
      } else
        onConfirm();
    } else {
      onCancle();
    }
    //Get.back();
  }

  Widget showBottomDialog(String key) {
    final formKey = GlobalKey<FormState>();
    return AlertDialog(
        content: Container(
            height: Get.height / 6,
            padding: EdgeInsets.only(
                bottom: MediaQuery.of(context).viewInsets.bottom),
            color: AppColors.white,
            child: Center(
                child: _key == null
                    ? Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        mainAxisSize: MainAxisSize.min,
                        children: <Widget>[
                          SizedBox(
                            height: FontSizes.s10,
                          ),
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: SizedBox(
                              width: Get.width / 2,
                              child: AppTextField(
                                hintText: Strings.employeeIdHint,
                                keyboardType: TextInputType.number,
                                inputFormatters: <TextInputFormatter>[
                                  FilteringTextInputFormatter.digitsOnly,
                                  LengthLimitingTextInputFormatter(6),
                                ],
                                textAlign: TextAlign.center,
                                controller: Get.find<DashboardController>()
                                    .empIdController,
                                hintStyle: TextStyles.textStyle
                                    .copyWith(fontSize: Sizes.s9),
                                // ),
                              ),
                            ),
                          ),
                          SizedBox(
                            height: FontSizes.s10,
                          ),
                          ElevatedButton(
                              child: Text('Scan',
                                  style: TextStyles.defaultRegular
                                      .copyWith(color: Colors.black87)),
                              style: ButtonStyle(
                                  backgroundColor: MaterialStateProperty.all(
                                      AppColors.primary),
                                  textStyle: MaterialStateProperty.all(
                                      const TextStyle(color: Colors.black87))),
                              onPressed: () {
                                String empId = dashboardController
                                        .empIdController.text.isEmpty
                                    ? null
                                    : dashboardController.empIdController.text;
                                this._key = empId;
                                setState(() {
                                  isBusy = false;
                                  save = false;
                                });
                                startTimer();
                                Get.back();
                                dashboardController.empIdController.clear();
                              }),
                          SizedBox(height: FontSizes.s10),
                        ],
                      )
                    : Container(
                        width: Get.width,
                        height: Get.height / 5,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SizedBox(
                              height: Sizes.s40,
                              width: Sizes.s140,
                              child: Row(
                                children: [
                                  ElevatedButton(
                                      onPressed: () =>
                                          onTappedManualPunchedIn(formKey),
                                      child: Text(Strings.IN)),
                                  ElevatedButton(
                                      onPressed: () =>
                                          onTappedManualPunchedOut(formKey),
                                      child: Text(Strings.OUT)),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ))));

    // showModalBottomSheet<void>(
    //   context: context,
    //   builder: (BuildContext context) {
    //     return SingleChildScrollView(
    //       child: Container(
    //         padding:
    //         EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
    //         color: AppColors.white,
    //         child: Center(
    //           child: Column(
    //             mainAxisAlignment: MainAxisAlignment.center,
    //             mainAxisSize: MainAxisSize.min,
    //             children: <Widget>[
    //               SizedBox(
    //                 height: FontSizes.s10,
    //               ),
    //               Padding(
    //                 padding: const EdgeInsets.all(8.0),
    //                 child: SizedBox(
    //                   width: Get.width/2,
    //                   child: AppTextField(
    //                           hintText: Strings.employeeIdHint,
    //                           keyboardType:TextInputType.number,
    //                           inputFormatters: <TextInputFormatter>[
    //                             FilteringTextInputFormatter.digitsOnly,
    //                             LengthLimitingTextInputFormatter(6),
    //                           ],
    //                     textAlign: TextAlign.center,
    //                     controller: Get.find<DashboardController>().empIdController,
    //                     hintStyle: TextStyles.textStyle.copyWith(fontSize: Sizes.s9),
    //                   ),
    //                 ),
    //               ) ,
    //               SizedBox(
    //                 height: FontSizes.s10,
    //               ),
    //               ElevatedButton(
    //                 child:  Text('Capture',style:  TextStyles.defaultRegular.copyWith(color: Colors.black87)),
    //                 style: ButtonStyle(
    //                     backgroundColor: MaterialStateProperty.all(AppColors.primary),
    //                     textStyle: MaterialStateProperty.all(const TextStyle(color: Colors.black87))
    //                 ),
    //                 onPressed: () {
    //                   String empId = dashboardController.empIdController.text.isEmpty ? null:dashboardController.empIdController.text;
    //
    //                       setState(() {
    //                         this._key = empId;
    //                         isBusy = false;
    //                       });
    //
    //                   Navigator.pop(context);
    //
    //               //    navigateToScanFace(empId,dashboardController.usernameController.text,isSignUp:false,mIsAuto: true,isDemo:dashboardController.isDemo);
    //                   dashboardController.empIdController.clear();
    //                 },
    //               ),
    //               SizedBox(
    //                 height: FontSizes.s10,
    //               ),
    //             ],
    //           ),
    //         ),
    //       ),
    //     );
    //   },
    //   isScrollControlled: true ,
    // );
  }

  void checkResultAndVerify(Map<String, dynamic> result,
      CameraController cameraController, XFile file, File captureImage,
      {bool isManual = false, String username, int Inout = -1}) async {
    if (isManual) {
      try {
        result = {};
        result['type'] = Inout;
        //   result["predRes"] = "$username:${widget.password}";
        faceDetectedCallback(result);
      } catch (ex) {
        print(ex.toString());
      }
    } else {
      print("result update");
    }
  }

  appUsernameEditText() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: Sizes.s15),
      child: AppTextField(
        keyboardType: TextInputType.text,
        inputFormatters: <TextInputFormatter>[
          FilteringTextInputFormatter.allow(RegExp("[a-zA-Z]"))
        ],
        controller: dashboardController.usernameController,
        hintText: Strings.enterUsername,
        mTextStyle: TextStyles.defaultRegular,
        validator: Validator.validateEmptyCheck,
      ),
    );
  }

  confirmButton(GlobalKey<FormState> key, int Inout) {
    return Center(
      child: SizedBox(
        width: Get.width * 0.25,
        child: ElevatedButton(
          onPressed: () {
            if (!key.currentState.validate()) return;

            checkResultAndVerify(result, cameraController, file, captureImage,
                isManual: true,
                username: dashboardController.usernameController.text,
                Inout: Inout);
            Get.back();
          },
          child: Row(
            children: [
              Text(Strings.done,
                  style: TextStyles.defaultRegular
                      .copyWith(fontSize: FontSizes.s14, color: Colors.white))
            ],
          ),
        ),
      ),
    );
  }

  void onTappedManualPunchedIn(GlobalKey<FormState> formKey) async {
    var out = await dashboardController.dbHelper
        .getIsPunched(int.parse(widget.empId), Inout: 1);
    if (out['type'] == "OUT" || out['type'] == 'FIRST') {
      if (cameraController.value.isStreamingImages)
        await cameraController.stopImageStream();
      Future.delayed(Duration.zero, () async {
        Get.back();
        Future.delayed(Duration.zero, () {
          Get.dialog(SimpleDialog(
            title: Text(
              Strings.manual_punch_dialog_title,
              style: TextStyles.title,
            ),
            children: [
              Form(
                key: formKey,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    appUsernameEditText(),
                    C15(),
                    confirmButton(formKey, 0)
                  ],
                ),
              )
            ],
          ));
        });
      });
    } else {
      Common.toast(Strings.alreadyPunchedIn);
    }
  }

  onTappedManualPunchedOut(GlobalKey<FormState> formKey) async {
    if (cameraController.value.isStreamingImages)
      await cameraController.stopImageStream();
    Future.delayed(Duration.zero, () async {
      Get.back();
      Future.delayed(Duration.zero, () {
        Get.dialog(SimpleDialog(
          title: Text(
            Strings.manual_punch_dialog_title,
            style: TextStyles.title,
          ),
          children: [
            Form(
              key: formKey,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  appUsernameEditText(),
                  C15(),
                  confirmButton(formKey, 1)
                ],
              ),
            )
          ],
        ));
      });
    });
  }
}
