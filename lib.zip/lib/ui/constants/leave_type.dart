enum LeaveStatus { approved, pending, rejected, undetermined }

enum LeaveType { ml, al, cl, undetermined }
