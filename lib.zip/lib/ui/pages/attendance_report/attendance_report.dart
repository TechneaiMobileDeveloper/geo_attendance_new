import 'package:flutter/material.dart';
import 'package:geo_attendance_system/res/app_colors.dart';
import 'package:geo_attendance_system/utils/utils_controller.dart';
import 'package:get/get.dart';

import '../../../res/strings.dart';

class AttendanceReport extends StatefulWidget {
  const AttendanceReport({Key key}) : super(key: key);

  @override
  State<AttendanceReport> createState() => _AttendanceReportState();
}

class _AttendanceReportState extends State<AttendanceReport> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: CustomAppBar(
          height: AppBar().preferredSize.height,
          title: Strings.attendanceReport,
          textStyle: TextStyles.appBarTittle.copyWith(color: AppColors.white),
          isBack: true,
        ),
      ),
    );
  }
}
