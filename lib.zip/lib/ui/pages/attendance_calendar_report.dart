import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:geo_attendance_system/controllers/report_controller.dart';
import 'package:geo_attendance_system/ui/widgets/custom_drop_down.dart';
import 'package:geo_attendance_system/ui/widgets/utils.dart';
import 'package:get/get.dart';
import 'package:search_choices/search_choices.dart';
import '../../controllers/attendance_controller.dart';
import '../../res/app_colors.dart';
import '../../res/strings.dart';
import '../../utils/sizes.dart';
import '../../utils/text_styles.dart';
import '../../utils/widget/custom_appbar.dart';
import '../widgets/calendar_widget.dart';

class AttendanceReport extends StatelessWidget {
  final AttendanceController attendanceController =
      Get.find<AttendanceController>();

  final ReportController reportController = Get.find<ReportController>();

  AttendanceReport({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final CalendarController controller =
        Get.put(CalendarController(attendanceController));
    return SafeArea(
      child: Scaffold(
        appBar: CustomAppBar(
          isHamburger: false,
          title: Strings.attendance,
          isBack: true,
          textStyle: TextStyles.appBarBold.copyWith(color: AppColors.white),
          color: AppColors.greyText,
        ),
        body: ReportBody(
            this.attendanceController, this.reportController, controller),
      ),
    );
  }
}

class ReportBody extends StatelessWidget {
  final AttendanceController attendanceController;
  final ReportController reportController;
  final CalendarController controller;

  ReportBody(this.attendanceController, this.reportController, this.controller,
      {Key key})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListView(
      shrinkWrap: true,
      children: [
        Obx(
          () => reportController.dropDownEmployeeList.length > 0
              ? Container(
                  width: Get.width,
                  decoration: BoxDecoration(
                      border:
                          Border.all(width: Sizes.s1, color: AppColors.primary),
                      borderRadius:
                          BorderRadius.all(Radius.circular(Sizes.s15))),
                  child: SearchChoices.single(
                    items: reportController.dropDownEmployeeList,
                    value: reportController.selectedEmployee,
                    searchHint: "Select one",
                    hint: 'Select one number',
                    underline: Container(),
                    onChanged: (DropDownModal value) {
                      if (kDebugMode) {
                        print(value.toString());
                      }
                      reportController.selectedEmployee.value = value;
                      controller.setEvents(attendanceController,
                          empId: value.index,
                          focusDate: controller.focusDate.value);
                    },
                    dialogBox: true,
                    isExpanded: true,
                  ),
                )
              : Container(),
        ),
        TableComplexExample(attendanceController, "", (DateTime value) {
          controller.focusDate.value = value;
        })
      ],
    );
  }
}
