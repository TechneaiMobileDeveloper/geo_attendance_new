import 'package:flutter/material.dart';

class ManualPunch extends StatefulWidget {
  const ManualPunch({Key key}) : super(key: key);

  @override
  _ManualPunchState createState() => _ManualPunchState();
}

class _ManualPunchState extends State<ManualPunch> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
