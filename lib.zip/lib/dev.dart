import 'app.dart';

void main() {
  App.instance.startApp(devMode: true);
}
