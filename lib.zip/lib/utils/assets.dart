class Assets {
  static const String techAi = 'assets/techAi.png';
  static const String mygoal = 'assets/mygoal_logo.jpeg';
  static const String direction = "assets/split.png";
}
