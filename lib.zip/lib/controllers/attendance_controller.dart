import 'package:flutter/material.dart';
import 'package:geo_attendance_system/network/api_client.dart';
import 'package:geo_attendance_system/network/urls.dart';
import 'package:geo_attendance_system/utils/methods.dart';
import 'package:get/get.dart';

class AttendanceController extends GetxController {
  APIClient apiClient = APIClient();
  final GlobalKey<ScaffoldState> scaffoldKey = new GlobalKey<ScaffoldState>();

  Future<dynamic> saveAttendanceOnServer(Map<String, dynamic> body) async {
    try {
      String url =
          await getIpAddress(temp: true) + AppUrl.saveAttendance; // todo
     dynamic response =  await apiClient.post(url, mapData: body);
     return response;
    } catch (ex) {
      print(ex.toString());
    }
  }
}
