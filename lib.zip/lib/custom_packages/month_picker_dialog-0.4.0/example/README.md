# month_picker_dialog_example

Demonstrates how to use the month_picker_dialog package.

## Screenshots
### Left-To-Right
![LTR portrait](../screenshots/ltr_portrait.png)
![LTR landscape](../screenshots/ltr_landscape.png)
### Right-To-Left
![RTL portrait](../screenshots/rtl_portrait.png)
![RTL landscape](../screenshots/rtl_landscape.png)
